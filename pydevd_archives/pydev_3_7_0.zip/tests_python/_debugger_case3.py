import time
if __name__ == '__main__':
    for i in range(15):
        print('here')
        time.sleep(.2)
    
    print('TEST SUCEEDED')
        
